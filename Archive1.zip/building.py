class Building():
    def __init__(self, x, y, latency, connection_speed):
        self.x = x
        self.y = y
        self.latency = latency
        self.connection_speed = connection_speed